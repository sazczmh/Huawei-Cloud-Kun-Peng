#global variable here
team_id = None

team_name = "example" # decided by yourself.