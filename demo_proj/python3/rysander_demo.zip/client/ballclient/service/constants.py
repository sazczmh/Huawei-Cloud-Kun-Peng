#global variable here
team_id = 1112

team_name = "rysander" # decided by yourself.