#global variable here
team_id = 1112

team_name = "sazczmh" # decided by yourself.